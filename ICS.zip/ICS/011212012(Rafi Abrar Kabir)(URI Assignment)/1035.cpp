#include<stdio.h>
int main()
{
    int a,b,c,d,sum1,sum2,ev;
    printf("Enter the Number of A B C D : ");
    scanf("%d%d%d%d",&a,&b,&c,&d);

    sum1=a+b;
    sum2=c+d;
    ev=a%2;
    if(b>c&&d>a&&sum2>sum1&&c>=0&&d>=0&&ev==0)
    {
        printf("Valores aceitos");
    }
    else
    {
        printf("valores nao aceitos");
    }
}
