#include<stdio.h>
#include<math.h>
int main()
{
	double a, b, c, tem,x,y;
	printf("\n Enter the first second and third floating Number : ");
    scanf("%lf",&a);
    scanf("%lf",&b);
    scanf("%lf",&c);


	tem = (b*b) - (4*(a)*(c));

    if(tem > 0 && a != 0)
    {
    tem = sqrt(tem);
    x = (-b + tem)/(2*a);
    y = (-b - tem)/(2*a);
    printf("Root1      =       %.5lf\n", x);
    printf("Root2 = %.5lf\n", y);
	}
	else
	 {
		printf("\n Impossivel calcular\n");
	}

	return 0;
}
